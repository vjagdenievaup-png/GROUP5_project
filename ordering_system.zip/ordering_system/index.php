<?php
session_start();

$users = [
    'admin' => '12345',
    'customer' => '54321'
]; # placeholder palang to wala pa dbms

if (!isset($_SESSION['user'])) {
    $_SESSION['user'] = "admin";
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['customer_login'])) {
        // Toggle role between admin and customer
        $_SESSION['user'] = ($_SESSION['user'] === "customer") ? "admin" : "customer";
    }
}

$role = $_SESSION['user']; #default

if (isset($_SESSION['username'])) {
    header("Location: welcome.php");
    exit;
}

// Handle form submission
$error = "";
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check credentials
    if (isset($users[$username]) && $users[$username] === $password) {
        $_SESSION['username'] = $username;
        $_SESSION['role'] = ($username === 'admin') ? 'admin' : 'customer';
        header("Location: welcome.php");
        exit;
    } else {
        $error = "Invalid username or password!";
    }
}
?>


<!DOCTYPE html>
<html>
<head>
  <title>Login Page</title>
  <link rel="stylesheet" type="text/css" href="assets/style.css">
</head>
<body>

<div class="box">
    <h2>Welcome!</h2>

     <?php if ($error != ""): ?>
      <p style="color:red;"><?= $error ?></p>
    <?php endif; ?>

    <form method="post">
      <input type="text" name="username" placeholder="Username" >
      <input type="password" name="password" placeholder="Password" >
      <button class="login_button" type="submit" name="login">Login</button>
      <button class="login_button customer" type="submit" name="customer_login">
      <?php
       echo ($role === "customer") ? "Login as Staff": "Login as customer";
      ?>
      </button>
  </div>

</body>
</html>